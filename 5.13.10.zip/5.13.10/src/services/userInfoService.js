import {postRequest} from "../utils/ajax";

export const getUserInfo = (userId, callback) => {
    const data = {userId: userId};
    const url = "http://localhost:8081/getUserInfo"
    postRequest(url, data, callback);
};
export const saveUserInfo = (userId, data, callback) => {
    data.userId = userId;
    // console.log(data);
    const url = "http://localhost:8081/saveUserInfo"
    postRequest(url, data, callback);
};