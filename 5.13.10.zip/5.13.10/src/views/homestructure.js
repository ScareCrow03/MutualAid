import {Button, Layout, Menu} from 'antd'
import "../css/homestructure.css"
import {
    DesktopOutlined,
    FileOutlined, PayCircleOutlined,
    PieChartOutlined,
    TeamOutlined,
    UserOutlined,
    ReadOutlined
} from '@ant-design/icons';
import {Link, Outlet} from "react-router-dom";

const  {Header,Content,Sider} = Layout;
const Homestructure=()=>{
    const getItem=(label, key, icon, children)=>{
        return {
            key,
            icon,
            children,
            label,
        };
    };
    let items = [
        getItem(<Link to="/">我的</Link>, '/', <PieChartOutlined />),
        getItem(<Link to="/community">社群</Link>, '/community',<DesktopOutlined />),
        getItem(<Link to="/message">消息</Link>, '/message',<TeamOutlined />),
        getItem(<Link to="/homepage">主页</Link>, '/homepage',<PayCircleOutlined />),
    ];
    return(
        <div classname="home">
            <div className="header">
                <div>
                    <div className={"header-left"}>
                        <div className="title">SJTU Stranding</div>
                        <div className="username">username:</div>
                    </div>
                    <div className="logo">
                        <img src="as.png" alt={"logo"}/>
                    </div>
                </div>
            </div>
            <Layout>
                <Sider width={200} className="sider" style={{float:"left"}}
                       collapsible={true}>
                    <Menu theme="dark" mode="inline" items={items} >
                    </Menu>
                </Sider>
                <Layout>
                    <Content className="content">
                        <Outlet/>
                    </Content>
                </Layout>
            </Layout>
        </div>
    )
}
export default Homestructure