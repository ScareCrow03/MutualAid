package com.reins.sjtu_stranding.entity;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
public class Liked {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "liked_id")
    private int likedId;
    @Basic
    @Column(name = "user_id")
    private int userId;
    @Basic
    @Column(name = "tag")
    private String tag;
    @Basic
    @Column(name = "score")
    private double score;

    public int getLikedId() {
        return likedId;
    }

    public void setLikedId(int likedId) {
        this.likedId = likedId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Liked liked = (Liked) o;
        return likedId == liked.likedId && userId == liked.userId && Double.compare(liked.score, score) == 0 && Objects.equals(tag, liked.tag);
    }

    @Override
    public int hashCode() {
        return Objects.hash(likedId, userId, tag, score);
    }
}
