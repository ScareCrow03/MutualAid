package com.reins.sjtu_stranding.repository;

import com.reins.sjtu_stranding.entity.Liked;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LikedRepository extends JpaRepository<Liked, Integer> {
    List<Liked> findLikedsByUserId(int userId);
    Liked findLikedByUserIdAndTag(int userId, String tag);
    List<Liked> findLikedsByUserIdAndTag(int userId, String tag);
}