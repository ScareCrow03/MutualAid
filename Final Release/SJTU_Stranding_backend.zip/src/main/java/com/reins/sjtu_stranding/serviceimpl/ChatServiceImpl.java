package com.reins.sjtu_stranding.serviceimpl;

import com.reins.sjtu_stranding.dao.ChatDao;
import com.reins.sjtu_stranding.entity.Chat;
import com.reins.sjtu_stranding.entity.ChatInfo;
import com.reins.sjtu_stranding.entity.User;
import com.reins.sjtu_stranding.service.ChatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ChatServiceImpl implements ChatService {

    @Autowired
    private ChatDao chatDao;

    @Override
    public List<Chat> getChat(int userId){
        List<Chat> c = chatDao.getChat(userId);
        int siz = c.size();
        for (int i = 0; i < siz; i++) {
            int sender = c.get(i).getSender(), receiver = c.get(i).getReceiver();
            int senderFlag = c.get(i).getSenderFlag(), receiverFlag = c.get(i).getReceiverFlag();
            User senderInfo = c.get(i).getSenderInfo(), receiverInfo = c.get(i).getReceiverInfo();
            if (receiver == userId) {
                c.get(i).setReceiver(sender);
                c.get(i).setSender(receiver);
                c.get(i).setReceiverFlag(senderFlag);
                c.get(i).setSenderFlag(receiverFlag);
                c.get(i).setReceiverInfo(senderInfo);
                c.get(i).setSenderInfo(receiverInfo);
            }
        }
        return c;
    }


    @Override
    public List<ChatInfo> getChatInfo(int chatId) {
        return chatDao.getChatInfo(chatId);
    }
    @Override
    public List<ChatInfo> sendChat(int sender, int receiver, String dialog) {
        return chatDao.sendChat(sender, receiver, dialog);
    }

    @Override
    public void addChat(int sender, int receiver) {
        chatDao.addChat(sender, receiver);
    }

    @Override
    public void visitChat(int chatId, int userId) {
        chatDao.visitChat(chatId, userId);
    }

}
