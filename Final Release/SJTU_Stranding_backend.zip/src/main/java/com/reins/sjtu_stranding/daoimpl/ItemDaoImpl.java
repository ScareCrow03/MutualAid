package com.reins.sjtu_stranding.daoimpl;

import com.reins.sjtu_stranding.dao.ItemDao;
import com.reins.sjtu_stranding.entity.Item;
import com.reins.sjtu_stranding.entity.Liked;
import com.reins.sjtu_stranding.repository.ItemRepository;
import com.reins.sjtu_stranding.repository.LikedRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

@Repository
public class ItemDaoImpl implements ItemDao {
    @Autowired
    private ItemRepository itemRepository;
    @Autowired
    private LikedRepository likedRepository;
    @Override
    public List<Item> getItems(int userId) {
        List<Item> f = itemRepository.findAll();
        List<Liked> g = likedRepository.findLikedsByUserId(userId);
        Map<String, Double> m = new HashMap<>();
        for (int i = 0; i < g.size(); i++)
            m.put(g.get(i).getTag(), g.get(i).getScore());
        double[] val = new double[f.size()];
        for (int i = 0; i < f.size(); i++) {
            val[i] = 0;
            Item x = f.get(i);
            String[] t = new String[]{x.getTag1(), x.getTag2(), x.getTag3()};
            for (int j = 0; j < 3; j++) if (t[j] != "")
                if (m.get(t[j]) != null) {
                    val[i] += m.get(t[j]);
//                    System.out.println(t[j]);
//                    System.out.println(m.get(t[j]));
                }
        }
        for (int i = 0; i < f.size(); i++) {
            System.out.println(val[i]);
            System.out.println(f.get(i).getTag1());
        }
        for (int i = 1; i < f.size(); i++)
            for (int j = 0; j < f.size() - i; j++) if (val[j] < val[j + 1]) {
                double tmp = val[j];
                val[j] = val[j + 1];
                val[j + 1] = tmp;
                Item sb = f.get(j);
                f.set(j, f.get(j + 1));
                f.set(j + 1, sb);
            }

        return f;
    }
    @Override
    public List<Item> getUserItem(int userId) {
        return itemRepository.findItemsByUserId(userId);
    }

    @Override
    public Item saveItem(int itemId, int userId, String name, String image, int number, String description, String tag1, String tag2, String tag3) {
        Item x = (itemId == 0) ? new Item() : itemRepository.findItemByItemId(itemId);
        x.setUserId(userId);
        x.setName(name);
        x.setImage(image);
        x.setNumber(number);
        x.setDescription(description);
        x.setTag1(tag1);
        x.setTag2(tag2);
        x.setTag3(tag3);
        return itemRepository.save(x);
    }

    @Override
    public List<Item> getItemsByX(String x) {
        return itemRepository.findItemsByNameContainingOrTag1ContainingOrTag2ContainingOrTag3Containing(x, x, x, x);
    }

    @Override
    public Item getItem(int itemId, int userId) {
        Item x = itemRepository.findItemByItemId(itemId);
        String[] t = new String[]{x.getTag1(), x.getTag2(), x.getTag3()};
        for (int i = 0; i < 3; i++) if (t[i].length() > 0) {
            List<Liked> li = likedRepository.findLikedsByUserIdAndTag(userId, t[i]);
            Liked l;
            if (li.size() == 0) {
                l = new Liked();
                l.setUserId(userId);
                l.setTag(t[i]);
                l.setScore(0.1);
            } else {
                l = li.get(0);
                l.setScore(l.getScore() + 0.1);
                if (li.size() >= 2) likedRepository.delete(li.get(1));
            }
            likedRepository.save(l);
        }
        return x;
    }


}
