package com.reins.sjtu_stranding.daoimpl;

import com.reins.sjtu_stranding.dao.ChatDao;
import com.reins.sjtu_stranding.entity.Chat;
import com.reins.sjtu_stranding.entity.ChatInfo;
import com.reins.sjtu_stranding.entity.User;
import com.reins.sjtu_stranding.repository.ChatInfoRepository;
import com.reins.sjtu_stranding.repository.ChatRepository;
import com.reins.sjtu_stranding.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
public class ChatDaoImpl implements ChatDao {
    @Autowired
    private ChatRepository chatRepository;
    @Override
    public List<Chat> getChat(int sender) {
        return chatRepository.findChatsBySenderOrReceiver(sender, sender);
    }
    @Autowired
    private ChatInfoRepository chatInfoRepository;
    @Autowired
    private UserRepository userRepository;

    @Override
    public List<ChatInfo> getChatInfo(int chatId) {
        return chatInfoRepository.findChatInfosByChatId(chatId);
    }
    @Override
    public List<ChatInfo> sendChat(int sender, int receiver, String dialog) {
        Timestamp ts = new Timestamp(System.currentTimeMillis());
        ChatInfo ci = new ChatInfo();
        ci.setSender(sender);
        ci.setReceiver(receiver);
        ci.setDialog(dialog);
        Chat c;
        if (sender < receiver) {
            c = chatRepository.findChatBySenderAndReceiver(sender, receiver);
            if (c.getReceiverFlag() == 0) {
                c.setReceiverFlag(1);
                User u = userRepository.findUserByUserId(c.getReceiver());
                u.setMessageFlag(u.getMessageFlag() + 1);
                userRepository.save(u);
                chatRepository.save(c);
            }
        }
        else {
            c = chatRepository.findChatBySenderAndReceiver(receiver, sender);
            if (c.getSenderFlag() == 0) {
                c.setSenderFlag(1);
                User u = userRepository.findUserByUserId(c.getSender());
                u.setMessageFlag(u.getMessageFlag() + 1);
                userRepository.save(u);
                chatRepository.save(c);
            }
        }

        ci.setTime(ts);
        int chatId = c.getChatId();
        ci.setChatId(chatId);
        chatInfoRepository.save(ci);
        return chatInfoRepository.findChatInfosByChatId(chatId);
    }
    @Override
    public void addChat(int sender, int receiver) {
        if (receiver < sender) {
            int tmp = sender;
            sender = receiver;
            receiver = tmp;
        }
        Chat c = chatRepository.findChatBySenderAndReceiver(sender, receiver);
        if (c == null) {
            c = new Chat();
            c.setSender(sender);
            c.setReceiver(receiver);
            c.setSenderFlag(0);
            c.setReceiverFlag(0);
            chatRepository.save(c);
        }
    }

    @Override
    public void visitChat(int chatId, int userId) {
        Chat c = chatRepository.findChatByChatId(chatId);
        if (c.getSender() == userId) {
            if (c.getSenderFlag() == 1) {
                c.setSenderFlag(0);
                User u = userRepository.findUserByUserId(userId);
                u.setMessageFlag(u.getMessageFlag() - 1);
            }
        }
        else {
            if (c.getReceiverFlag() == 1) {
                c.setReceiverFlag(0);
                User u = userRepository.findUserByUserId(userId);
                u.setMessageFlag(u.getMessageFlag() - 1);
            }
        }
        chatRepository.save(c);
    }

}
