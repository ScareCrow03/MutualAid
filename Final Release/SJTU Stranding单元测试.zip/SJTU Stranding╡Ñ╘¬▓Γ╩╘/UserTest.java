package com.example.demo.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.Test;
import org.junit.Before;
import org.junit.After;

/**
 * User Tester.
 *
 * @author <Authors name>
 * @version 1.0
 * @since <pre>5月 13, 2023</pre>
 */
public class UserTest {

    @Before
    public void before() throws Exception {
    }

    @After
    public void after() throws Exception {
    }

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>default or parameterless constructor of {@link User}
     *   <li>{@link User#setAddress(String)}
     *   <li>{@link User#setAvatar(String)}
     *   <li>{@link User#setDescription(String)}
     *   <li>{@link User#setEmail(String)}
     *   <li>{@link User#setNickname(String)}
     *   <li>{@link User#setQq(String)}
     *   <li>{@link User#setScore(double)}
     *   <li>{@link User#setTelephone(String)}
     *   <li>{@link User#setUserId(int)}
     *   <li>{@link User#getAddress()}
     *   <li>{@link User#getAvatar()}
     *   <li>{@link User#getDescription()}
     *   <li>{@link User#getEmail()}
     *   <li>{@link User#getNickname()}
     *   <li>{@link User#getQq()}
     *   <li>{@link User#getScore()}
     *   <li>{@link User#getTelephone()}
     *   <li>{@link User#getUserId()}
     * </ul>
     */
    @org.junit.jupiter.api.Test
    void testConstructor() {
        User actualUser = new User();
        actualUser.setAddress("42 Main St");
        actualUser.setAvatar("Avatar");
        actualUser.setDescription("The characteristics of someone or something");
        actualUser.setEmail("jane.doe@example.org");
        actualUser.setNickname("Nickname");
        actualUser.setQq("Qq");
        actualUser.setScore(10.0d);
        actualUser.setTelephone("6625550144");
        actualUser.setUserId(1);
        assertEquals("42 Main St", actualUser.getAddress());
        assertEquals("Avatar", actualUser.getAvatar());
        assertEquals("The characteristics of someone or something", actualUser.getDescription());
        assertEquals("jane.doe@example.org", actualUser.getEmail());
        assertEquals("Nickname", actualUser.getNickname());
        assertEquals("Qq", actualUser.getQq());
        assertEquals(10.0d, actualUser.getScore());
        assertEquals("6625550144", actualUser.getTelephone());
        assertEquals(1, actualUser.getUserId());
    }

    /**
     * Method under test: {@link User#equals(Object)}
     */
    @org.junit.jupiter.api.Test
    void testEquals2() {
        User user = new User();
        user.setAddress("42 Main St");
        user.setAvatar("Avatar");
        user.setDescription("The characteristics of someone or something");
        user.setEmail("jane.doe@example.org");
        user.setNickname("Nickname");
        user.setQq("Qq");
        user.setScore(10.0d);
        user.setTelephone("6625550144");
        user.setUserId(1);
        assertNotEquals(user, null);
    }

    /**
     * Method under test: {@link User#equals(Object)}
     */
    @org.junit.jupiter.api.Test
    void testEquals3() {
        User user = new User();
        user.setAddress("42 Main St");
        user.setAvatar("Avatar");
        user.setDescription("The characteristics of someone or something");
        user.setEmail("jane.doe@example.org");
        user.setNickname("Nickname");
        user.setQq("Qq");
        user.setScore(10.0d);
        user.setTelephone("6625550144");
        user.setUserId(1);
        assertNotEquals(user, "Different type to User");
    }

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>{@link User#equals(Object)}
     *   <li>{@link User#hashCode()}
     * </ul>
     */
    @org.junit.jupiter.api.Test
    void testEquals4() {
        User user = new User();
        user.setAddress("42 Main St");
        user.setAvatar("Avatar");
        user.setDescription("The characteristics of someone or something");
        user.setEmail("jane.doe@example.org");
        user.setNickname("Nickname");
        user.setQq("Qq");
        user.setScore(10.0d);
        user.setTelephone("6625550144");
        user.setUserId(1);
        assertEquals(user, user);
        int expectedHashCodeResult = user.hashCode();
        assertEquals(expectedHashCodeResult, user.hashCode());
    }

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>{@link User#equals(Object)}
     *   <li>{@link User#hashCode()}
     * </ul>
     */
    @org.junit.jupiter.api.Test
    void testEquals5() {
        User user = new User();
        user.setAddress("42 Main St");
        user.setAvatar("Avatar");
        user.setDescription("The characteristics of someone or something");
        user.setEmail("jane.doe@example.org");
        user.setNickname("Nickname");
        user.setQq("Qq");
        user.setScore(10.0d);
        user.setTelephone("6625550144");
        user.setUserId(1);

        User user2 = new User();
        user2.setAddress("42 Main St");
        user2.setAvatar("Avatar");
        user2.setDescription("The characteristics of someone or something");
        user2.setEmail("jane.doe@example.org");
        user2.setNickname("Nickname");
        user2.setQq("Qq");
        user2.setScore(10.0d);
        user2.setTelephone("6625550144");
        user2.setUserId(1);
        assertEquals(user, user2);
        int expectedHashCodeResult = user.hashCode();
        assertEquals(expectedHashCodeResult, user2.hashCode());
    }

    /**
     * Method under test: {@link User#equals(Object)}
     */
    @org.junit.jupiter.api.Test
    void testEquals6() {
        User user = new User();
        user.setAddress("17 High St");
        user.setAvatar("Avatar");
        user.setDescription("The characteristics of someone or something");
        user.setEmail("jane.doe@example.org");
        user.setNickname("Nickname");
        user.setQq("Qq");
        user.setScore(10.0d);
        user.setTelephone("6625550144");
        user.setUserId(1);

        User user2 = new User();
        user2.setAddress("42 Main St");
        user2.setAvatar("Avatar");
        user2.setDescription("The characteristics of someone or something");
        user2.setEmail("jane.doe@example.org");
        user2.setNickname("Nickname");
        user2.setQq("Qq");
        user2.setScore(10.0d);
        user2.setTelephone("6625550144");
        user2.setUserId(1);
        assertNotEquals(user, user2);
    }

    /**
     * Method under test: {@link User#equals(Object)}
     */
    @org.junit.jupiter.api.Test
    void testEquals7() {
        User user = new User();
        user.setAddress("42 Main St");
        user.setAvatar(null);
        user.setDescription("The characteristics of someone or something");
        user.setEmail("jane.doe@example.org");
        user.setNickname("Nickname");
        user.setQq("Qq");
        user.setScore(10.0d);
        user.setTelephone("6625550144");
        user.setUserId(1);

        User user2 = new User();
        user2.setAddress("42 Main St");
        user2.setAvatar("Avatar");
        user2.setDescription("The characteristics of someone or something");
        user2.setEmail("jane.doe@example.org");
        user2.setNickname("Nickname");
        user2.setQq("Qq");
        user2.setScore(10.0d);
        user2.setTelephone("6625550144");
        user2.setUserId(1);
        assertNotEquals(user, user2);
    }

    /**
     * Method under test: {@link User#equals(Object)}
     */
    @org.junit.jupiter.api.Test
    void testEquals8() {
        User user = new User();
        user.setAddress("42 Main St");
        user.setAvatar("Avatar");
        user.setDescription("Description");
        user.setEmail("jane.doe@example.org");
        user.setNickname("Nickname");
        user.setQq("Qq");
        user.setScore(10.0d);
        user.setTelephone("6625550144");
        user.setUserId(1);

        User user2 = new User();
        user2.setAddress("42 Main St");
        user2.setAvatar("Avatar");
        user2.setDescription("The characteristics of someone or something");
        user2.setEmail("jane.doe@example.org");
        user2.setNickname("Nickname");
        user2.setQq("Qq");
        user2.setScore(10.0d);
        user2.setTelephone("6625550144");
        user2.setUserId(1);
        assertNotEquals(user, user2);
    }

    /**
     * Method under test: {@link User#equals(Object)}
     */
    @org.junit.jupiter.api.Test
    void testEquals9() {
        User user = new User();
        user.setAddress("42 Main St");
        user.setAvatar("Avatar");
        user.setDescription("The characteristics of someone or something");
        user.setEmail("john.smith@example.org");
        user.setNickname("Nickname");
        user.setQq("Qq");
        user.setScore(10.0d);
        user.setTelephone("6625550144");
        user.setUserId(1);

        User user2 = new User();
        user2.setAddress("42 Main St");
        user2.setAvatar("Avatar");
        user2.setDescription("The characteristics of someone or something");
        user2.setEmail("jane.doe@example.org");
        user2.setNickname("Nickname");
        user2.setQq("Qq");
        user2.setScore(10.0d);
        user2.setTelephone("6625550144");
        user2.setUserId(1);
        assertNotEquals(user, user2);
    }

    /**
     * Method under test: {@link User#equals(Object)}
     */
    @org.junit.jupiter.api.Test
    void testEquals10() {
        User user = new User();
        user.setAddress("42 Main St");
        user.setAvatar("Avatar");
        user.setDescription("The characteristics of someone or something");
        user.setEmail("jane.doe@example.org");
        user.setNickname(null);
        user.setQq("Qq");
        user.setScore(10.0d);
        user.setTelephone("6625550144");
        user.setUserId(1);

        User user2 = new User();
        user2.setAddress("42 Main St");
        user2.setAvatar("Avatar");
        user2.setDescription("The characteristics of someone or something");
        user2.setEmail("jane.doe@example.org");
        user2.setNickname("Nickname");
        user2.setQq("Qq");
        user2.setScore(10.0d);
        user2.setTelephone("6625550144");
        user2.setUserId(1);
        assertNotEquals(user, user2);
    }

    /**
     * Method under test: {@link User#equals(Object)}
     */
    @org.junit.jupiter.api.Test
    void testEquals11() {
        User user = new User();
        user.setAddress("42 Main St");
        user.setAvatar("Avatar");
        user.setDescription("The characteristics of someone or something");
        user.setEmail("jane.doe@example.org");
        user.setNickname("Nickname");
        user.setQq(null);
        user.setScore(10.0d);
        user.setTelephone("6625550144");
        user.setUserId(1);

        User user2 = new User();
        user2.setAddress("42 Main St");
        user2.setAvatar("Avatar");
        user2.setDescription("The characteristics of someone or something");
        user2.setEmail("jane.doe@example.org");
        user2.setNickname("Nickname");
        user2.setQq("Qq");
        user2.setScore(10.0d);
        user2.setTelephone("6625550144");
        user2.setUserId(1);
        assertNotEquals(user, user2);
    }

    /**
     * Method under test: {@link User#equals(Object)}
     */
    @org.junit.jupiter.api.Test
    void testEquals12() {
        User user = new User();
        user.setAddress("42 Main St");
        user.setAvatar("Avatar");
        user.setDescription("The characteristics of someone or something");
        user.setEmail("jane.doe@example.org");
        user.setNickname("Nickname");
        user.setQq("Qq");
        user.setScore(0.5d);
        user.setTelephone("6625550144");
        user.setUserId(1);

        User user2 = new User();
        user2.setAddress("42 Main St");
        user2.setAvatar("Avatar");
        user2.setDescription("The characteristics of someone or something");
        user2.setEmail("jane.doe@example.org");
        user2.setNickname("Nickname");
        user2.setQq("Qq");
        user2.setScore(10.0d);
        user2.setTelephone("6625550144");
        user2.setUserId(1);
        assertNotEquals(user, user2);
    }

    /**
     * Method under test: {@link User#equals(Object)}
     */
    @org.junit.jupiter.api.Test
    void testEquals13() {
        User user = new User();
        user.setAddress("42 Main St");
        user.setAvatar("Avatar");
        user.setDescription("The characteristics of someone or something");
        user.setEmail("jane.doe@example.org");
        user.setNickname("Nickname");
        user.setQq("Qq");
        user.setScore(10.0d);
        user.setTelephone("8605550118");
        user.setUserId(1);

        User user2 = new User();
        user2.setAddress("42 Main St");
        user2.setAvatar("Avatar");
        user2.setDescription("The characteristics of someone or something");
        user2.setEmail("jane.doe@example.org");
        user2.setNickname("Nickname");
        user2.setQq("Qq");
        user2.setScore(10.0d);
        user2.setTelephone("6625550144");
        user2.setUserId(1);
        assertNotEquals(user, user2);
    }

    /**
     * Method under test: {@link User#equals(Object)}
     */
    @org.junit.jupiter.api.Test
    void testEquals14() {
        User user = new User();
        user.setAddress("42 Main St");
        user.setAvatar("Avatar");
        user.setDescription("The characteristics of someone or something");
        user.setEmail("jane.doe@example.org");
        user.setNickname("Nickname");
        user.setQq("Qq");
        user.setScore(10.0d);
        user.setTelephone("6625550144");
        user.setUserId(2);

        User user2 = new User();
        user2.setAddress("42 Main St");
        user2.setAvatar("Avatar");
        user2.setDescription("The characteristics of someone or something");
        user2.setEmail("jane.doe@example.org");
        user2.setNickname("Nickname");
        user2.setQq("Qq");
        user2.setScore(10.0d);
        user2.setTelephone("6625550144");
        user2.setUserId(1);
        assertNotEquals(user, user2);
    }

    /**
     * Method: getUserId()
     */
    @Test
    public void testGetUserId() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: setUserId(int userId)
     */
    @Test
    public void testSetUserId() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: getNickname()
     */
    @Test
    public void testGetNickname() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: setNickname(String nickname)
     */
    @Test
    public void testSetNickname() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: getTelephone()
     */
    @Test
    public void testGetTelephone() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: setTelephone(String telephone)
     */
    @Test
    public void testSetTelephone() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: getEmail()
     */
    @Test
    public void testGetEmail() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: setEmail(String email)
     */
    @Test
    public void testSetEmail() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: getAddress()
     */
    @Test
    public void testGetAddress() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: setAddress(String address)
     */
    @Test
    public void testSetAddress() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: getScore()
     */
    @Test
    public void testGetScore() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: setScore(double score)
     */
    @Test
    public void testSetScore() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: getAvatar()
     */
    @Test
    public void testGetAvatar() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: setAvatar(String avatar)
     */
    @Test
    public void testSetAvatar() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: getQq()
     */
    @Test
    public void testGetQq() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: setQq(String qq)
     */
    @Test
    public void testSetQq() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: getDescription()
     */
    @Test
    public void testGetDescription() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: setDescription(String description)
     */
    @Test
    public void testSetDescription() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: equals(Object o)
     */
    @Test
    public void testEquals() throws Exception {
//TODO: Test goes here...
    }

    /**
     * Method: hashCode()
     */
    @Test
    public void testHashCode() throws Exception {
//TODO: Test goes here...
    }


}