import {postRequest} from "../utils/ajax";

export const getcommunities=(callback)=>{
    const url = "http://localhost:8081/getCommunity"
    postRequest(url, null, callback);
}

export const getCommunityInfo=(communityId,callback)=>{
    const data={communityId:communityId}
    const url = "http://localhost:8081/getPost"
    postRequest(url, data, callback);
}

export const addNews=(communityId,userId,value,callback)=>{
    const data={communityId:communityId,userId:userId,info:value}
    const url="http://localhost:8081/savePost"
    postRequest(url,data,callback)
}