import Search from "antd/es/input/Search";
import "../css/itemdetailview.css";
import type, {Button} from "antd";
import {addFavorite} from "../services/favoriteService";
import {message} from "antd";

const Itemdetailview=(props)=>{
    const [messageApi, contextHolder] = message.useMessage();
    const item=props.item
    const user={
        userid:2,
        nickname:'ILoLy',
        telephone:'1501740364',
        email:'iloly10@sjtu.edu.cn',
        address:'SJTU-X12',
        score:'4.8',
        avatar:'http://img3m7.ddimg.cn/48/0/24106647-1_w_6.jpg',
        qq:'3440233385',
        description:'我是用户zyc！'
    }

    function like_callback() {
        messageApi.open({
            type:'success',
            content:'收藏成功！'
        })
    }

    function like(){
        // console.log(localStorage.getItem("userId"))
        addFavorite(localStorage.getItem("userId"),item.item_id,like_callback)
    }
    return(
        <div>
            <Search
                placeholder="输入搜索内容..."
                allowClear
                enterButton="Search"
                size="large"
                rootClassName="search"
            />
            <div className="itemdetail">
                <img src={item.image} className={"itemimage"}/>
                <div className={"description"}>
                    物品名称:  {item.name}<br/><br/>
                    用户评分:  {user.score}<br/><br/>
                    简介: {item.description}
                </div>
                <div className={"buttons"}>
                    <Button type={"primary"} className={"button"}>私聊</Button>
                    <Button type={"primary"} className={"button"}>交易</Button>
                    <Button type={"primary"} onClick={like}>喜欢</Button>
                </div>
            </div>
        </div>
    )
}
export default Itemdetailview