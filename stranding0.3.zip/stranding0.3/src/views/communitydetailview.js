import {useParams} from "react-router-dom"
import "../css/communitydetailview.css"
import {Card,Button,Modal,Form,Input} from 'antd'
import {PlusCircleOutlined} from '@ant-design/icons';
import React, {useEffect, useState} from 'react'
import {addNews, getCommunityInfo} from "../services/communityService";
const Communitydetailview=()=>{
    const params=useParams();
    const [isModalOpen,setIsModalOpen]=useState(false)
    const {TextArea}=Input
    const [news,setNews]=useState()
    useEffect(()=>{
        getCommunityInfo(params.id,callback)
    },[])
    function callback(data){
        setNews(data)
    }
    function showmodal(){
        setIsModalOpen(true)
    }
    function handlecancel(){
        setIsModalOpen(false)
    }
    function handleform(value){
        //TODO:发布post请求
        addNews(params.id,localStorage.getItem("userId"),value.info,add_callback)
        handlecancel()
    }
    function add_callback(data){
        getCommunityInfo(params.id,callback)
    }
    // const news=[
    //     {
    //         userName:"Iloly",
    //         time:"2023-5-12 22:10:15",
    //         info:"我大郑老师阅片无数"
    //     },
    //     {
    //         userName:"Iloly",
    //         time:"2023-5-12 22:10:15",
    //         info:"我大郑老师阅片无数"
    //     },
    //     {
    //         userName:"Iloly",
    //         time:"2023-5-12 22:10:15",
    //         info:"我大郑老师阅片无数"
    //     },
    //     {
    //         userName:"Iloly",
    //         time:"2023-5-12 22:10:15",
    //         info:"我大郑老师阅片无数"
    //     },
    //     {
    //         userName:"Iloly",
    //         time:"2023-5-12 22:10:15",
    //         info:"我大郑老师阅片无数"
    //     },
    //     {
    //         userName:"Iloly",
    //         time:"2023-5-12 22:10:15",
    //         info:"我大郑老师阅片无数"
    //     },
    //     {
    //         userName:"Iloly",
    //         time:"2023-5-12 22:10:15",
    //         info:"我大郑老师阅片无数"
    //     }
    // ]
    return(
        <div className="news">
            <Button icon={<PlusCircleOutlined />} onClick={showmodal}>
                我要发贴
            </Button>
            {news?.map(news=>{
                return(
                    <>
                        <Card style={{
                            marginTop:20
                        }}>
                            <div>
                                <div >发帖人:{news.user.nickname}</div>
                                <div >发帖时间:{news.time}</div>
                            </div>
                            <div className={"newsinfo"}>
                                {news.info}
                            </div>
                            <Button type={"primary"}>私聊</Button>
                        </Card>
                    </>
                )
            })}
            <Modal open={isModalOpen} footer={null} title={"发布帖子"} onCancel={handlecancel}>
                <Form onFinish={handleform}>
                    <Form.Item name="info" rules={[{
                        required:true,
                        message:'请输入内容！'
                    }]}>
                        <TextArea rows={10}/>
                    </Form.Item>
                    <Form.Item>
                        <Button htmlType={'submit'}>发布</Button>
                    </Form.Item>
                </Form>
            </Modal>
        </div>
    )
}
export default Communitydetailview