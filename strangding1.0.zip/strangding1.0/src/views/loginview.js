import "../css/loginview.css"
import {Button, Card, Checkbox, Form, Input,Modal} from "antd";
import {UserOutlined,LockOutlined} from "@ant-design/icons";
import * as PropTypes from "prop-types";
import {userLogin} from "../services/userInfoService";
import {createBrowserHistory} from 'history'
import {useState} from 'react'

const Loginview=(props)=>{
    const history=createBrowserHistory()
    const [isModalOpen,setIsModalOpen]=useState(false)

    function onFinish(value) {
        userLogin(value.username,value.password,login_callback)
    }

    function login_callback(data){
        if(data==null){
            console.log("NONE");
        }
        else{
            localStorage.setItem("userId",data)
            history.push('/')
            history.go(0)
        }
    }

    function showmodal(){
        setIsModalOpen(true)
    }

    return (
        <div className={"login"}>
            <Card className={"login-container"}>
                <Form
                    className="login-form"
                    onFinish={onFinish}
                >
                    <Form.Item
                        name="username"
                        rules={[
                            {
                                required: true,
                                message: '请输入用户名',
                            },
                        ]}
                    >
                        <Input prefix={<UserOutlined className="site-form-item-icon" />} placeholder="用户名" />
                    </Form.Item>
                    <Form.Item
                        name="password"
                        rules={[
                            {
                                required: true,
                                message: '请输入密码！',
                            },
                        ]}
                    >
                        <Input
                            prefix={<LockOutlined className="site-form-item-icon" />}
                            type="password"
                            placeholder="密码"
                        />
                    </Form.Item>
                    {/*<Form.Item>*/}
                    {/*    <Form.Item name="remember" valuePropName="checked" noStyle>*/}
                    {/*        <Checkbox>Remember me</Checkbox>*/}
                    {/*    </Form.Item>*/}

                    {/*    <a className="login-form-forgot" href="">*/}
                    {/*        Forgot password*/}
                    {/*    </a>*/}
                    {/*</Form.Item>*/}

                    <Form.Item>
                        <Button type="primary" htmlType="submit" className="login-form-button" block={true}>
                            登录
                        </Button>
                        或 <Button style={{marginTop:20}} type={"primary"} onClick={showmodal}>立即注册!</Button>
                    </Form.Item>
                </Form>
            </Card>
            <Modal open={isModalOpen}>

            </Modal>
        </div>
    )
}

export default Loginview