const Communityview=()=>{
    return (
        <div>
            community
        </div>
    )
}
export default  Communityview