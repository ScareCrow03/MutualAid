const Messageview=()=>{
    return (
        <div>
            message;
        </div>
    )
}

export default  Messageview;