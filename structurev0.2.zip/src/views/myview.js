const Myview=()=>{
    return (
        <div>
            myview
        </div>
    )
}
export default Myview