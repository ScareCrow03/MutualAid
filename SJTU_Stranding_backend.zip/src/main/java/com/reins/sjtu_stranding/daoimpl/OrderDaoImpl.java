package com.reins.sjtu_stranding.daoimpl;

import com.reins.sjtu_stranding.dao.OrderDao;
import com.reins.sjtu_stranding.entity.Item;
import com.reins.sjtu_stranding.entity.Order;
import com.reins.sjtu_stranding.repository.ItemRepository;
import com.reins.sjtu_stranding.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
public class OrderDaoImpl implements OrderDao {
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private ItemRepository itemRepository;
    @Override
    public List<Order> getOrder(int userId) {
        return orderRepository.findOrdersByUserIdOrBuyer(userId, userId);
    }

    @Override
    public void saveOrder(int itemId, int buyer, short state) {
        Order o = new Order();
        o.setItemId(itemId);
        o.setBuyer(buyer);
        o.setState(state);
        Timestamp ts = new Timestamp(System.currentTimeMillis());
        o.setTime(ts);
        Item i = itemRepository.findItemByItemId(itemId);
        i.setState((short) 1);
        o.setUserId(i.getUserId());
        itemRepository.save(i);
        orderRepository.save(o);
    }

}
