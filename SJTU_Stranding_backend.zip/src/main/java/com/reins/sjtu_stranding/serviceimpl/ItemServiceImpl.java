package com.reins.sjtu_stranding.serviceimpl;

import com.reins.sjtu_stranding.dao.ItemDao;
import com.reins.sjtu_stranding.entity.Item;
import com.reins.sjtu_stranding.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ItemServiceImpl implements ItemService {

    @Autowired
    private ItemDao ItemDao;
    @Override
    public List<Item> getItems(){
        return ItemDao.getItems();
    }
    @Override
    public Item getItem(int itemId){
        return ItemDao.getItem(itemId);
    }
    @Override
    public List<Item> getUserItem(int userId){
        return ItemDao.getUserItem(userId);
    }

    @Override
    public Item saveItem(int itemId, int userId, String name, String image, int number, String description, String tag1, String tag2, String tag3) {
        return ItemDao.saveItem(itemId, userId, name, image, number, description, tag1, tag2, tag3);
    }
}
