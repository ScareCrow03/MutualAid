import {Carousel} from "antd";
import Search from "antd/es/input/Search";
import {Link} from "react-router-dom";
import "../css/homepage.css"

const Homeview=(props)=>{
    const items=props.items
    return (
        <div>
            <Search
                placeholder="输入搜索内容..."
                allowClear
                enterButton="Search"
                size="large"
                rootClassName="search"
            />
            <Carousel autoplay className="carousel">
                <div className="carouselitem">
                    <Link to="/homepage/detail1"><img src={require('../pictures/book1.jpg')} alt="123"/></Link>
                </div>
                <div className="carouselitem">
                    <Link to="/homepage/detail2"><img src={require('../pictures/book2.jpg')}/></Link>
                </div>
                <div className="carouselitem">
                    <Link to="/homepage/detail3"><img src={require('../pictures/book3.jpg')}/></Link>
                </div>
                <div className="carouselitem">
                    <Link to="/homepage/detail4"><img src={require('../pictures/book4.jpg')}/></Link>
                </div>
            </Carousel>
            {
                items.map(item=>{
                  if(item.state==0){
                      return (
                          <Link to={'detail'+item.item_id}>
                              <img src={item.image} style={{
                                  width:"300px",
                                  height:"150px",
                                  float:"left",
                                  marginRight:20
                              }}/>
                          </Link>
                      )
                  }
                  else{
                      return null
                  }
                })
            }
        </div>
    )
}
export default Homeview