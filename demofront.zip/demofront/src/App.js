import logo from './logo.svg';
import './App.css';
import Homestructure from "./views/homestructure";
import {BrowserRouter, Route, Routes} from "react-router-dom";
import Myview from "./views/myview";
import Communityview from "./views/communityview";
import Messageview from "./views/messageview";
import Homeview from "./views/homeview";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route exact path='/' element={<Homestructure></Homestructure>}>
            <Route exact index element={<Myview></Myview>}/>
            <Route exact path='community' element={<Communityview></Communityview>}/>
            <Route exact path='message' element={<Messageview></Messageview>}/>
            <Route exact path='homepage' element={<Homeview></Homeview>}/>
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
