import {Carousel} from "antd";
import Search from "antd/es/input/Search";


const Homeview=()=>{
    return (
        <div>
            <Search
                placeholder="输入搜索内容..."
                allowClear
                enterButton="Search"
                size="large"
                rootClassName="search"
            />
            <Carousel>

            </Carousel>
        </div>
    )
}
export default Homeview