import { AppstoreOutlined, MailOutlined, SettingOutlined } from '@ant-design/icons';
import { Menu } from 'antd';
import { useState } from 'react';
const items = [
    {
        label: 'Navigation One',
        key: 'mail',
        icon: <MailOutlined />,
    },
    {
        label: 'Navigation One',
        key: '1',
        icon: <MailOutlined />,
    },
    {
            label: 'Navigation One',
            key: '2',
            icon: <MailOutlined />,
    },
    {
            label: 'Navigation One',
            key: '3',
            icon: <MailOutlined />,
     },

];
const Communityview = () => {
    const [current, setCurrent] = useState('mail');
    const onClick = (e) => {
        console.log('click ', e);
        setCurrent(e.key);
    };
    return <Menu onClick={onClick} selectedKeys={[current]} mode="horizontal" items={items} />;
};
export default Communityview;